﻿using System;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace Client
{
    class Program
    {
        public static void PrintHoldShipmentLabel(string orderNum, DateTime orderDate, long custNum, string InboundAWB)
        {
            string currentDir = Directory.GetCurrentDirectory();
            try
            {
                using (var fs = new FileStream((currentDir + "\\Label.pdf"), FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    using (Document doc = new Document())
                    {
                        using (var docWriter = PdfWriter.GetInstance(doc, fs))
                        {
                            doc.Open();

                            Paragraph title = new Paragraph("\n\n\nHOLD\nSHIPMENT\n\n");
                            title.Font.Size = 30;
                            title.Alignment = Element.ALIGN_CENTER;
                            doc.Add(title);

                            Paragraph OrderAndCustNum = new Paragraph(string.Format("Order Num: {0}\nOrder Date: {1}\nCustomer Num: {2}\n",
                                orderNum, orderDate.ToShortDateString(), custNum.ToString()));
                            doc.Add(OrderAndCustNum);

                            Paragraph AWB = new Paragraph(String.Format("Domestic AWB: \n{0}", InboundAWB));
                            doc.Add(AWB);

                            //generate barcode and add to PDF
                            Barcode128 bc = new Barcode128();
                            bc.Code = InboundAWB;
                            var bcImg = bc.CreateDrawingImage(System.Drawing.Color.Black, System.Drawing.Color.White);
                            Image pdfImag = Image.GetInstance(bcImg, System.Drawing.Imaging.ImageFormat.Jpeg);
                            doc.Add(pdfImag);

                            doc.Close();
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                Console.WriteLine("Error in generating PDF " + exp.Message);
            }

            Console.WriteLine("PDF is generated. Please check result in {0}\\Label.pdf", currentDir);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Start test");
            PrintHoldShipmentLabel("1200", DateTime.Now, 123456, "281444022585");
            Console.WriteLine("\nPress any key to end the test");
            Console.Read();
        }
    }
}
